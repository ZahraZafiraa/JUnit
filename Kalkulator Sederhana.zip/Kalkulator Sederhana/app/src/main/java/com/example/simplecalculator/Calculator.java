package com.example.simplecalculator;

/**
 * Kelas Calculator
 *
 * Kelas ini menyediakan metode untuk melakukan operasi matematika dasar
 * seperti penjumlahan, pengurangan, perkalian, dan pembagian.
 * Setiap metode menerima dua parameter bertipe double dan mengembalikan hasil perhitungannya.
 */
public class Calculator {

    /**
     * Menjumlahkan dua angka.
     *
     * @param a angka pertama
     * @param b angka kedua
     * @return hasil penjumlahan a + b
     */
    public double add(double a, double b) {
        return a + b;
    }

    /**
     * Mengurangkan angka kedua dari angka pertama.
     *
     * @param a angka pertama
     * @param b angka kedua
     * @return hasil pengurangan a - b
     */
    public double subtract(double a, double b) {
        return a - b;
    }

    /**
     * Mengalikan dua angka.
     *
     * @param a angka pertama
     * @param b angka kedua
     * @return hasil perkalian a * b
     */
    public double multiply(double a, double b) {
        return a * b;
    }

    /**
     * Membagi angka pertama dengan angka kedua.
     *
     * @param a angka pembilang
     * @param b angka penyebut
     * @return hasil pembagian a / b
     * @throws IllegalArgumentException jika b adalah 0
     */
    public double divide(double a, double b) {
        if (b == 0) {
            throw new IllegalArgumentException("Cannot divide by zero");
        }
        return a / b;
    }
}
