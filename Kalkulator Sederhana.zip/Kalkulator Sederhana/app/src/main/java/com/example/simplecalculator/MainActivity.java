package com.example.simplecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Kelas MainActivity
 *
 * Kelas ini menangani antarmuka pengguna untuk aplikasi kalkulator sederhana.
 * Pengguna dapat memasukkan dua angka dan melakukan operasi matematika dasar
 * seperti penjumlahan, pengurangan, perkalian, dan pembagian.
 */
public class MainActivity extends AppCompatActivity {

    // Deklarasi variabel untuk referensi ke elemen UI
    private EditText editTextFirstNumber, editTextSecondNumber;
    private Button buttonAdd, buttonSubtract, buttonMultiply, buttonDivide, buttonClear;
    private TextView textViewResult;

    // Instance dari kelas Calculator untuk melakukan perhitungan
    private Calculator calculator;

    /**
     * Metode ini dipanggil ketika activity dibuat
     * Menyiapkan tata letak dan menginisialisasi komponen UI
     *
     * @param savedInstanceState data state sebelumnya dari activity
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Membuat instance baru dari kelas Calculator
        calculator = new Calculator();

        // Inisialisasi elemen UI dengan mencari ID dari layout
        initializeViews();

        // Mengatur listener untuk setiap tombol operasi
        setupListeners();
    }

    /**
     * Metode untuk menginisialisasi semua elemen UI
     * Metode ini menghubungkan variabel dengan elemen UI berdasarkan ID
     */
    private void initializeViews() {
        // Menghubungkan EditText dengan variabel
        editTextFirstNumber = findViewById(R.id.editTextFirstNumber);
        editTextSecondNumber = findViewById(R.id.editTextSecondNumber);

        // Menghubungkan Button dengan variabel
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonSubtract = findViewById(R.id.buttonSubtract);
        buttonMultiply = findViewById(R.id.buttonMultiply);
        buttonDivide = findViewById(R.id.buttonDivide);
        buttonClear = findViewById(R.id.buttonClear);

        // Menghubungkan TextView hasil dengan variabel
        textViewResult = findViewById(R.id.textViewResult);
    }

    /**
     * Metode untuk mengatur semua listener untuk tombol
     * Setiap tombol akan memanggil fungsi perhitungan yang sesuai ketika diklik
     */
    private void setupListeners() {
        // Listener untuk tombol tambah
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Memanggil metode performOperation dengan operasi tambah
                performOperation('+');
            }
        });

        // Listener untuk tombol kurang
        buttonSubtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Memanggil metode performOperation dengan operasi kurang
                performOperation('-');
            }
        });

        // Listener untuk tombol kali
        buttonMultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Memanggil metode performOperation dengan operasi kali
                performOperation('*');
            }
        });

        // Listener untuk tombol bagi
        buttonDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Memanggil metode performOperation dengan operasi bagi
                performOperation('/');
            }
        });

        // Listener untuk tombol reset
        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Mengosongkan input dan hasil
                clearFields();
            }
        });
    }

    /**
     * Metode untuk melakukan operasi perhitungan berdasarkan tipe operasi
     * Metode ini akan memvalidasi input, melakukan perhitungan menggunakan
     * kelas Calculator, dan menampilkan hasilnya
     *
     * @param operationType karakter yang menunjukkan tipe operasi ('+', '-', '*', '/')
     */
    private void performOperation(char operationType) {
        // Mendapatkan nilai dari input
        String firstNumberStr = editTextFirstNumber.getText().toString();
        String secondNumberStr = editTextSecondNumber.getText().toString();

        // Validasi input agar tidak kosong
        if (firstNumberStr.isEmpty() || secondNumberStr.isEmpty()) {
            Toast.makeText(this, "Mohon isi kedua angka terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // Konversi string input menjadi angka
            double firstNumber = Double.parseDouble(firstNumberStr);
            double secondNumber = Double.parseDouble(secondNumberStr);
            double result = 0;

            // Melakukan operasi matematika berdasarkan tipe operasi
            switch (operationType) {
                case '+':
                    // Operasi penambahan menggunakan kelas Calculator
                    result = calculator.add(firstNumber, secondNumber);
                    break;
                case '-':
                    // Operasi pengurangan menggunakan kelas Calculator
                    result = calculator.subtract(firstNumber, secondNumber);
                    break;
                case '*':
                    // Operasi perkalian menggunakan kelas Calculator
                    result = calculator.multiply(firstNumber, secondNumber);
                    break;
                case '/':
                    // Operasi pembagian dengan validasi pembagian dengan nol
                    if (secondNumber == 0) {
                        // Menampilkan pesan kesalahan jika pembagi adalah nol
                        textViewResult.setText("Tidak dapat membagi dengan nol");
                        return;
                    }
                    result = calculator.divide(firstNumber, secondNumber);
                    break;
            }

            // Menampilkan hasil dengan format "Hasil: [hasil]"
            if (result % 1 == 0) {
                textViewResult.setText("Hasil: " + (int) result);
            } else {
                textViewResult.setText("Hasil: " + result);
            }


        } catch (NumberFormatException e) {
            // Menangani kesalahan format input
            Toast.makeText(this, "Input tidak valid", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Metode untuk mengosongkan semua input dan hasil
     * Dipanggil ketika tombol reset diklik
     */
    private void clearFields() {
        // Mengosongkan input pertama
        editTextFirstNumber.setText("");

        // Mengosongkan input kedua
        editTextSecondNumber.setText("");

        // Mereset tampilan hasil
        textViewResult.setText("Hasil: 0");

        // Memberikan fokus ke input pertama
        editTextFirstNumber.requestFocus();
    }
}