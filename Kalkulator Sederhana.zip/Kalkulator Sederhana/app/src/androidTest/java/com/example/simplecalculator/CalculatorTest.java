package com.example.simplecalculator;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Kelas CalculatorTest
 *
 * Kelas ini berisi kumpulan local unit test untuk menguji fungsionalitas
 * dari kelas Calculator. Setiap test case memverifikasi bahwa operasi
 * matematika dasar berfungsi dengan benar dalam berbagai kondisi.
 */
public class CalculatorTest {

    private Calculator calculator;

    /**
     * Metode yang dijalankan sebelum setiap test case
     * Membuat instance baru dari kelas Calculator untuk pengujian
     */
    @Before
    public void setUp() {
        calculator = new Calculator();
    }

    /**
     * Test Case 1: Verifikasi bahwa metode add() menambahkan dua angka positif dengan benar
     *
     * Pengujian ini memeriksa apakah kalkulator dapat melakukan penjumlahan
     * dua angka positif dengan benar. Kita mengharapkan 5 + 3 sama dengan 8.
     *
     * Metode ini menggunakan pola Arrange-Act-Assert:
     * - Arrange: menyiapkan data uji (5 dan 3)
     * - Act: menjalankan operasi yang diuji (penjumlahan)
     * - Assert: memverifikasi hasil (8)
     */
    @Test
    public void add_TwoPositiveNumbers_ReturnsCorrectSum() {
        // Arrange - menyiapkan data uji
        double a = 5;
        double b = 3;
        double expected = 8;

        // Act - melakukan operasi penjumlahan
        double result = calculator.add(a, b);

        // Assert - memeriksa hasil
        assertEquals("Penambahan 5 dan 3 seharusnya menghasilkan 8", expected, result, 0.0001);
    }

    /**
     * Test Case 2: Verifikasi bahwa metode divide() melempar IllegalArgumentException saat membagi dengan nol
     *
     * Pembagian dengan nol secara matematis tidak terdefinisi, sehingga kalkulator
     * seharusnya melempar IllegalArgumentException ketika mencoba melakukan
     * pembagian dengan nol. Test case ini memverifikasi perilaku tersebut.
     *
     * Anotasi @Test(expected = IllegalArgumentException.class) menunjukkan
     * bahwa test case ini diharapkan melempar IllegalArgumentException.
     */
    @Test(expected = IllegalArgumentException.class)
    public void divide_ByZero_ThrowsIllegalArgumentException() {
        // Arrange - menyiapkan data uji
        double a = 10;
        double b = 0;

        // Act & Assert - melakukan operasi dan memverifikasi bahwa exception dilempar
        calculator.divide(a, b); // Ini seharusnya melempar IllegalArgumentException
    }

    /**
     * Test Case 3: Verifikasi bahwa metode subtract() menangani hasil negatif dengan benar
     *
     * Test case ini memastikan bahwa kalkulator dapat menangani operasi
     * pengurangan yang menghasilkan angka negatif dengan benar.
     * Dalam hal ini, 5 - 8 seharusnya menghasilkan -3.
     */
    @Test
    public void subtract_SecondNumberLarger_ReturnsNegativeResult() {
        // Arrange - menyiapkan data uji
        double a = 5;
        double b = 8;
        double expected = -3;

        // Act - melakukan operasi pengurangan
        double result = calculator.subtract(a, b);

        // Assert - memeriksa hasil
        assertEquals("Pengurangan 5 oleh 8 seharusnya menghasilkan -3", expected, result, 0.0001);
    }

    /**
     * Test Case 4: Verifikasi bahwa metode multiply() menangani angka desimal dengan benar
     *
     * Test case ini memeriksa apakah kalkulator dapat mengalikan angka desimal dengan akurat.
     * Aritmatika desimal terkadang dapat menimbulkan kesalahan presisi,
     * sehingga kita menggunakan delta dalam assertion untuk memperhitungkan
     * perbedaan kecil dalam floating-point.
     */
    @Test
    public void multiply_DecimalNumbers_ReturnsCorrectProduct() {
        // Arrange - menyiapkan data uji
        double a = 2.5;
        double b = 4;
        double expected = 10;

        // Act - melakukan operasi perkalian
        double result = calculator.multiply(a, b);

        // Assert - memeriksa hasil
        assertEquals("Perkalian 2.5 dengan 4 seharusnya menghasilkan 10", expected, result, 0.0001);
    }
}
