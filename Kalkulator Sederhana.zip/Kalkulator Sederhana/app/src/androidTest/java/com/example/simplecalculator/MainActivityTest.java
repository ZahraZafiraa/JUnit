package com.example.simplecalculator;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.espresso.Espresso;
import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.assertion.ViewAssertions;
import androidx.test.espresso.matcher.ViewMatchers;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.closeSoftKeyboard;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

/**
 * Kelas MainActivityTest
 *
 * Kelas ini berisi kumpulan instrumentation test untuk menguji fungsionalitas UI
 * dari kelas MainActivity. Pengujian ini menjalankan aplikasi dan mensimulasikan
 * interaksi pengguna untuk memverifikasi bahwa UI bekerja dengan benar.
 */
@RunWith(AndroidJUnit4.class)
public class MainActivityTest {

    /**
     * ActivityScenarioRule adalah rule JUnit yang meluncurkan activity
     * untuk setiap test case dan menutupnya setelah test case selesai.
     */
    @Rule
    public ActivityScenarioRule<MainActivity> activityRule = new ActivityScenarioRule<>(MainActivity.class);

    /**
     * Test Case 1: Verifikasi fungsi penjumlahan di UI
     *
     * Test case ini mensimulasikan pengguna memasukkan dua angka dan
     * menekan tombol penjumlahan, kemudian memeriksa apakah hasil yang
     * ditampilkan sesuai dengan yang diharapkan.
     *
     * Langkah-langkah:
     * 1. Masukkan "10" pada kolom input pertama
     * 2. Masukkan "5" pada kolom input kedua
     * 3. Klik tombol tambah (+)
     * 4. Verifikasi bahwa TextView hasil menampilkan "Hasil: 15"
     */
    @Test
    public void testAddOperation() {
        // Masukkan nilai pada kolom input
        onView(withId(R.id.editTextFirstNumber))
                .perform(typeText("10"), closeSoftKeyboard());
        onView(withId(R.id.editTextSecondNumber))
                .perform(typeText("5"), closeSoftKeyboard());

        // Klik tombol tambah
        onView(withId(R.id.buttonAdd))
                .perform(click());

        // Verifikasi hasilnya
        onView(withId(R.id.textViewResult))
                .check(matches(withText("Hasil: 15.0")));
    }

    /**
     * Test Case 2: Verifikasi fungsi pembagian di UI
     *
     * Test case ini mensimulasikan pengguna memasukkan dua angka dan
     * menekan tombol pembagian, kemudian memeriksa apakah hasil yang
     * ditampilkan sesuai dengan yang diharapkan.
     *
     * Langkah-langkah:
     * 1. Masukkan "20" pada kolom input pertama
     * 2. Masukkan "4" pada kolom input kedua
     * 3. Klik tombol bagi (÷)
     * 4. Verifikasi bahwa TextView hasil menampilkan "Hasil: 5"
     */
    @Test
    public void testDivideOperation() {
        // Masukkan nilai pada kolom input
        onView(withId(R.id.editTextFirstNumber))
                .perform(typeText("20"), closeSoftKeyboard());
        onView(withId(R.id.editTextSecondNumber))
                .perform(typeText("4"), closeSoftKeyboard());

        // Klik tombol bagi
        onView(withId(R.id.buttonDivide))
                .perform(click());

        // Verifikasi hasilnya
        onView(withId(R.id.textViewResult))
                .check(matches(withText("Hasil: 5")));
    }

    /**
     * Test Case 3: Verifikasi fungsi perkalian di UI
     *
     * Test case ini mensimulasikan pengguna memasukkan dua angka (termasuk desimal)
     * dan menekan tombol perkalian, kemudian memeriksa apakah hasil yang
     * ditampilkan sesuai dengan yang diharapkan.
     *
     * Langkah-langkah:
     * 1. Masukkan "2.5" pada kolom input pertama
     * 2. Masukkan "3" pada kolom input kedua
     * 3. Klik tombol kali (×)
     * 4. Verifikasi bahwa TextView hasil menampilkan "Hasil: 7.5"
     */
    @Test
    public void testMultiplyOperation() {
        // Masukkan nilai pada kolom input
        onView(withId(R.id.editTextFirstNumber))
                .perform(typeText("2.5"), closeSoftKeyboard());
        onView(withId(R.id.editTextSecondNumber))
                .perform(typeText("3"), closeSoftKeyboard());

        // Klik tombol kali
        onView(withId(R.id.buttonMultiply))
                .perform(click());

        // Verifikasi hasilnya
        onView(withId(R.id.textViewResult))
                .check(matches(withText("Hasil: 7.5")));
    }

    /**
     * Test Case 4: Verifikasi pembagian dengan nol di UI
     *
     * Test case ini mensimulasikan pengguna mencoba melakukan pembagian dengan nol
     * dan memeriksa apakah aplikasi menampilkan pesan kesalahan yang sesuai.
     *
     * Langkah-langkah:
     * 1. Masukkan "10" pada kolom input pertama
     * 2. Masukkan "0" pada kolom input kedua
     * 3. Klik tombol bagi (÷)
     * 4. Verifikasi bahwa TextView hasil menampilkan pesan "Tidak dapat membagi dengan nol"
     */
    @Test
    public void testDivideByZero() {
        // Masukkan nilai pada kolom input
        onView(withId(R.id.editTextFirstNumber))
                .perform(typeText("10"), closeSoftKeyboard());
        onView(withId(R.id.editTextSecondNumber))
                .perform(typeText("0"), closeSoftKeyboard());

        // Klik tombol bagi
        onView(withId(R.id.buttonDivide))
                .perform(click());

        // Verifikasi hasilnya menampilkan pesan kesalahan
        onView(withId(R.id.textViewResult))
                .check(matches(withText("Tidak dapat membagi dengan nol")));
    }
}